"""
Ref: https://github.com/ultralytics/ultralytics/issues/18204#issuecomment-2541446929
"""
from ultralytics.data.loaders import LoadPilAndNumpy, LoadImagesAndVideos, SourceTypes
from ultralytics.models.sam import SAM2VideoPredictor, SAM2Predictor
from PIL import Image as PILImg
import numpy as np
import cv2
import os
from pathlib import Path
from  ultralytics.cfg import get_save_dir



from types import SimpleNamespace
root_dir = "/home/<user>/Projects/iteachSkillsApp/Python/data_captured/0418T120046/"
rgb_dir = f"{root_dir}/rgb"
parent_dir = os.path.dirname(rgb_dir)
jpg_dir = os.path.join(parent_dir, "jpg")

os.makedirs(jpg_dir, exist_ok=True)

files = sorted(os.listdir(rgb_dir), reverse=True)

jpg_imgs = []

for i, file in enumerate(files):
    if file.lower().endswith(".png"):
        img_path = os.path.join(rgb_dir, file)
        img = PILImg.open(img_path).convert("RGB")
        
        # Format with zero-padded 5-digit filename
        jpg_filename = f"{i:05d}.jpg"  # Equivalent to %05d in old-style formatting
        
        jpg_path = os.path.join(jpg_dir, jpg_filename)
        img.save(jpg_path, "JPEG")
        jpg_imgs.append(jpg_filename)

numpy_images = []
rgb_imgs = []
# for file in sorted(os.listdir(f"{rgb_dir}"), reverse=True):
#     print(f"{rgb_dir}/{file}")
#     numpy_images.append(PILImg.open(f"{rgb_dir}/{file}"))
#     rgb_imgs.append(PILImg.open(f"{rgb_dir}/{file}.replace('png','jpg')"))

overrides = dict(conf=0.25, task="segment", mode="predict", imgsz=1024, model="sam2_l.pt")
predictor = SAM2VideoPredictor(overrides=overrides)

# import pdb; pdb.set_trace()
args = SimpleNamespace(project=root_dir, name="sam2-results", exist_ok=True)
predictor.save_dir = get_save_dir(args)

# loader = LoadPilAndNumpy(rgb_imgs)
folder = f"{rgb_dir}/*"
loader = LoadImagesAndVideos(folder)
loader.source_type = SourceTypes()
# import pdb; pdb.set_trace()
loader.frames = loader.ni
# loader.nf = loader.ni = 1
loader.files = [os.path.join(rgb_dir, x) for x in sorted(os.listdir(rgb_dir), reverse=True)]
loader.frame = 0
loader.mode = "video"
# loader.video_flag = [True]
loader.fps = 30

# [[302., 128.,  90., 144.]

# [[257.,  56., 347., 200.]]

results = predictor(source=loader, bboxes=[[257.,  56., 347., 200.]])
print(len(results))

